Independent archive corpus
